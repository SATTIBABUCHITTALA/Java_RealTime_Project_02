public class EmployeeServiceImpl{

public static void main(String args[]){

Employee employee =new Employee();
employee.empId="101";
employee.empName ="Shivesh";

Employee employee1 =new Employee();
employee1.empId="102";
employee1.empName ="Harikha";

Employee employee2 =new Employee();
employee2.empId="103";
employee2.empName ="Nikhila";

EmployeeDetails empDetails =new EmployeeDetails();
String name =empDetails.getEmployeeName(employee);
System.out.println("Name of the Employee of given Object is "+name);

empDetails =new EmployeeDetails();
name =empDetails.getEmployeeName(employee1);
System.out.println("Name of the Employee of given Object is "+name);

empDetails =new EmployeeDetails();
name =empDetails.getEmployeeName(employee2);
System.out.println("Name of the Employee of given Object is "+name);


}

}