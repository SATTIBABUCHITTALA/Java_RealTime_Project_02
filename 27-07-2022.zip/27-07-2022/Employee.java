public class Employee{


String empId;
String empName;
String empSalary;

}