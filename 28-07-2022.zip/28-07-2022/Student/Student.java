public class Student {

String studentId; //common or different
String studentName; //common or different
static String principalName;// common or different class level variable  


}