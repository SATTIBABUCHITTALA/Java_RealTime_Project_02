public class StudentMain{


public static void main(String args[]){

Student.principalName ="Kiran";






Student student =new Student();
student.studentId ="101";
student.studentName ="Nikhila"; 


System.out.println(student.studentId);
System.out.println(student.studentName);
System.out.println(student.principalName);

Student student1 =new Student();

student1.studentId ="102";
student1.studentName ="Harikha";


System.out.println("----------------------");
System.out.println(student1.studentId);
System.out.println(student1.studentName);
System.out.println(student1.principalName);

StudentDetailsImpl studentDetails =new StudentDetailsImpl();
//studentDetails.isStudentPass(student);

}



}