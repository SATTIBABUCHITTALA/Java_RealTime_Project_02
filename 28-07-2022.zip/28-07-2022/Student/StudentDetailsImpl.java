class StudentDetailsImpl{

String studentName1 ="Harikha"; //instance variable (or) object variables

void isStudentPass(Student student){

String stdName = student.studentName; //local variables local methods 

System.out.println("Student is passed "+stdName + " " +studentName1 ) ;

}

}