import com.sun.xml.internal.ws.api.model.wsdl.WSDLOutput;
//Object is the super class for all the class
class D {



    void getClassDetails_D(){
        System.out.println("In Class D");
    }
}
class E extends D{

    void getClassDetails_E(){
        System.out.println("In Class D");
    }

}
class A extends D{
    void getClassDetails_A(){
        System.out.println("In Class A");
    }

}
class B extends A{
    void getClassDetails_B(){
        System.out.println("In Class B");
    }

}
class C extends B{
    void getClassDetailsC(){
        System.out.println("In Class C");
    }
}

public class InheritanceDemo {


    public static void main(String args[]){

        C c =new C();
        c.getClassDetailsC();
        c.getClassDetails_B();
        c.getClassDetails_A();
        c.getClassDetails_D();
    }

}
