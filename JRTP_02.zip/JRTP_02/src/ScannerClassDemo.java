import java.util.Scanner;


public class ScannerClassDemo {
    private static String name1;
    static{
      System.out.println("Satic block ");
    }

    public static void main(String args[]){
        Scanner scr=new Scanner(System.in);
        System.out.println("Enter your Name ");
        String name =scr.next();
        System.out.println("Enter your Age ");

        int age=scr.nextInt();
        if(age<17 && age>0){
            System.out.println("Not Eligible for Voting Sorry !!! " +name );
        }else if(age>=17 && age<101){
            System.out.println("Eligible for Voting " +name);
        }else {
            System.out.println("Invalid Input " +name);
        }

    }




}
