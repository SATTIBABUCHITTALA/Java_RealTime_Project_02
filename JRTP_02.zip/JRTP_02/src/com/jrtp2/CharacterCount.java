package com.jrtp2;

public class CharacterCount {

    // Online Java Compiler
// Use this editor to write, compile and run your Java code online



        public static void main(String[] args) {
            System.out.println("Hello, World!");

            String str="Myname is Satti babu chittala";
            str=str.toLowerCase();

            HelloWorld.getCharacterCount(str);



        }
        static void getCharacterCount(String str){

            try{
                if(str ==null  || str.trim().isEmpty() ){
                    throw new NullPointerException("Please Provide proper String");
                }
                System.out.println(str);
                char[]  charSet=str.stringTokenizer();
                Arrays.sort(charSet);
                int count=0;
                boolean flag=false;
                for(int i=0;i<charSet.length-1;){
                    flag=false;
                    count=0;
                    while(!flag){

                        if(charSet[i]!=' '&& charSet[i]==charSet[i+1]){
                            i++;
                            count++;
                        }else{
                            flag=true;
                            System.out.println("Count of"+charSet[i]+ "is"+count);
                        }
                    }
                }

            }catch(NullPointerException ne){
                System.out.println(ne);
            }

        }
    }




