package com.jrtp2;

import java.io.*;

public class FileHandling {

    public static void main(String[] args) throws IOException {
        File file=new File("C:/Users/schitta/Desktop/MyData1.txt");

        FileWriter fileWriter =new FileWriter(file,true); //constructor
        fileWriter.write("Sattibabu \n");
        fileWriter.write("Bye ");
        fileWriter.write("\n");
        fileWriter.close();



        FileReader   bf=new FileReader(file);
        BufferedReader bufferedReader =new BufferedReader(bf);
        String line="";
        while((line=bufferedReader.readLine()) !=null){

            System.out.println(line);

        }

        bf.close();
        //streams ----> Character streaming, Binary data
        //Writer
        //FileWriter
        //BufferedWriter





        if(file.createNewFile()){

            System.out.println("File Reading" +file.canRead());
            System.out.println("File Reading" +file.canWrite());
            System.out.println("File Reading" +file.length());
        }

    }
}
