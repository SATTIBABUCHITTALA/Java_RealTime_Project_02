package com.jrtp2.model;

public class Book {

   public String bookId; //default accessmodifier is default
   public String bookName;
   public  double bookPrice;



}
