package com.jrtp2;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import static java.lang.Thread.sleep;

interface F1{
   default void add(){

   }

}
@FunctionalInterface
interface F2 extends F1{
   void add();
}
class Hi extends Thread{
    @Override
    public void run(){

        for(int i=0;i<5;i++){

            System.out.println("Hi");
            try {
                sleep(1000); //sleeping 0.5 sec
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
class Hello extends Thread {

    @Override
    public void run(){

        for(int i=0;i<5;i++){

            System.out.println("Hello");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }



}
public class ThreadClass {


    public static void main(String args[]) throws InterruptedException {


        Hi hi=new Hi();
        Hello hello=new Hello();
        hi.start();


        hello.start();
        Thread.sleep(1000);
        hi.join();
        hello.join();
        System.out.println("Completed");



        String str="Sattibabu chittala";
       Map<String, Long> map= Arrays.stream(str.split("")).collect(
            Collectors.groupingBy(Function.identity(),Collectors.counting()));
        System.out.println(map);


    }
}
