package com.jrtp2;

import java.util.Optional;
import java.util.function.Supplier;

interface i1{
  void getData();

   default void getData2(){
       System.out.println("Hi");
   }



}
interface i2{
    void getData();

    default void getData2(){
        System.out.println("Hi");
    }



}
class C1 implements i1,i2{

    String name = "Sattibabu" ;
    String id;
    String cls;

    @Override
    public void getData() {

    }

    @Override
    public void getData2() {
        i2.super.getData2();
    }



}
class c2 implements i1{


    @Override
    public void getData() {

    }
}

public class DefaultMethod {

    public static void main(String args[]){
        Optional<C1> c1= Optional.of(new C1());



        //Optional class is class which has certian methods to check null pointer exception
        //

       if(c1.isPresent() && c1.get().name.equals("Sattibabu")){
           System.out.println("Hello "+ c1.get().name.isEmpty());
       }
       String str=null;
       if(str!=null ){

       }
       Optional<String> optional=Optional.of("sattibabu");
       optional=null;
       String str2=optional.orElse("Chittala");
        System.out.println(str2);







       C1 c2=new C1();


    }
}
