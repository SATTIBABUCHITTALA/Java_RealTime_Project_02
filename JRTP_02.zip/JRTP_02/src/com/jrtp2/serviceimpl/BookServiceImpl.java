package com.jrtp2.serviceimpl;

import com.jrtp2.model.Book;

public class BookServiceImpl {


    public String isBookAvailabe(String bookId){  //returnType methodname(Paramerters){}

        if(bookId == "101f" || bookId == "102f")
        return "Book is Available !!!";
        else
            return "Book is Not Available";
    }

    public Book printBookDetails(String bookId){

        Book book=new Book();
        if(bookId =="101f"){
            book.bookId ="101f";
            book.bookPrice=345.56;
            book.bookName="Java HeadFirst";

        return book;
        }else {
            return null;
        }


    }

}
