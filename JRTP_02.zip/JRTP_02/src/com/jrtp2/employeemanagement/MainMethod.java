package com.jrtp2.employeemanagement;

import java.util.*;

public class MainMethod {

    public static void main(String args[]){

        EmployeeServiceImpl employeeServiceImpl =new EmployeeServiceImpl();
        List<Employee> employeeList =new ArrayList<Employee>();


        employeeList.add(new Employee("107", "Shivesh", 35000));
        employeeList.add(new Employee("124", "Harikha", 28000));
        employeeList.add(new Employee("108", "Rajesh", 22000));
        employeeList.add(new Employee("101", "Shiva", 85000));

        employeeServiceImpl.getEmployeesSorted(employeeList,"Name");
        for(Employee emp:employeeList)
            /*if(emp.getEmpSalary()<35000)
                employeeList.remove(emp);*/
            System.out.println(emp);

        //Collections.sort(employeeList);

        Collections.reverse(employeeList);

        System.out.println("After Sorting Elements based on Salary");
        for(Employee emp:employeeList)
            System.out.println(emp);

//Set will have only unique elements 23,34,23,45
        //HashSet --------23,34,45 ----> Not Following the insertion order 34,45,23
        //LinkedHashSet ----> 23,34,45, ---following the insertion order 23,34,45

        //TreeSet ----> 45,23,34 ----> Give me the sorted order 23,34,45

        HashSet<Integer> hashSet =new HashSet<Integer>();
        hashSet.add(23);
        hashSet.add(56);
        hashSet.add(34);
        System.out.println(hashSet);


        int[] nums =  new int[] {1, 1, 2, 3, 3, 3};
        Arrays.sort(nums);
        int [] duplicates =new int[5];
        for (int i = 0; i < nums.length-1; i++) {

            if (nums[i] == nums[i+1]) {
                duplicates[i] =nums[i];
            }
            for(int V: duplicates)
            System.out.println(V);
        }



    }
}
