package com.jrtp2.employeemanagement;

import com.jrtp2.employeemanagement.Employee;

import java.util.List;

public interface EmployeeService {

    List<Employee> getEmployeesSorted(List<Employee> employeeList,String sortedByParameter);



}
