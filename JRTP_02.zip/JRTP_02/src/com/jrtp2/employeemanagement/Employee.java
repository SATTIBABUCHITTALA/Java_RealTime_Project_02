package com.jrtp2.employeemanagement;

public class Employee implements Comparable<Employee>{

    public Employee(String empId, String empName, double empSalary) {
        this.empName = empName;
        this.empId = empId;
        this.empSalary = empSalary;
    }

    public Employee() {
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getEmpId() {
        return empId;
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public double getEmpSalary() {
        return empSalary;
    }

    public void setEmpSalary(double empSalary) {
        this.empSalary = empSalary;
    }

    private String empName;
    private String empId;
    private double empSalary;


    @Override
    public String toString() {
        return "Employee{" +
            "empName='" + empName + '\'' +
            ", empId='" + empId + '\'' +
            ", empSalary=" + empSalary +
            '}';
    }

    @Override
    public int compareTo(Employee o) {
        return this.getEmpId().compareTo(o.getEmpId());
        //return this.getEmpName().compareTo(o.getEmpName());
        //return (int) (this.getEmpSalary() -o.getEmpSalary()); //45000,25000, //0,>0,<0  25-25 =0,25-45(-25)
        //45-25 (positive)
    }
}
