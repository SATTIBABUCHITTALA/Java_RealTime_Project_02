package com.jrtp2.employeemanagement;

import com.jrtp2.employeemanagement.Employee;
import com.jrtp2.employeemanagement.EmployeeService;

import java.util.*;
import java.util.stream.Collectors;

public class EmployeeServiceImpl implements EmployeeService {
    @Override
    public List<Employee> getEmployeesSorted(List<Employee> employeeList, String sortedByParameter) {


        Comparator<Employee> compareEmpId=new Comparator<Employee>() {
            @Override
            public int compare(Employee o1, Employee o2) {
                return o1.getEmpId().compareTo(o2.getEmpId());
            }
        };

        Comparator<Employee> compareEmpName=new Comparator<Employee>() {
            @Override
            public int compare(Employee o1, Employee o2) {
                return o1.getEmpName().compareTo(o2.getEmpName());
            }
        };

        Comparator<Employee> compareEmpSalary=new Comparator<Employee>() {
            @Override
            public int compare(Employee o1, Employee o2) {
                return o1.getEmpName().compareTo(o2.getEmpName());
            }
        };
        List<String> original = new ArrayList<>();
        original.add("4");
        original.add("3");
        original.add("5");
        original.add("4");


        List<String> result = new ArrayList<>();

        result = original.stream().filter(e-> Collections.frequency(original,e)>1).distinct().collect(Collectors.toList());
        System.out.println(result);
        Collections.sort(employeeList,compareEmpId);
        Collections.sort(employeeList,compareEmpName);



















        return null;
    }
}
