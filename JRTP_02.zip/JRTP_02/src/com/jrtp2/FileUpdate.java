package com.jrtp2;


import java.io.*;

public class FileUpdate {
    public static void replaceSelected(String replaceWith, String type) throws IOException {
        try {
            // input the file content to the StringBuffer "input"
            File f=new File("C:/Users/schitta/Desktop/MyData.txt");
            BufferedReader file = new BufferedReader(new FileReader(f));
            StringBuffer inputBuffer = new StringBuffer();
            String line="";
            while ((line = file.readLine()) != null) {
                inputBuffer.append(line);
                inputBuffer.append('\n');
            }
            file.close();
            String inputStr = inputBuffer.toString();

            System.out.println(inputStr); // display the original file for debugging

            int wordIndex = inputStr.indexOf("Hello");
            System.out.println("WordIndex"+wordIndex);
            inputStr = inputStr.replace("Hello","Satti");//0, wordIndex ) + "Satti" + inputStr.substring(wordIndex , inputStr.length());

            // display the new file for debugging
            System.out.println("----------------------------------\n" + inputStr);

            // write the updated content with the new string OVER the same file
            FileOutputStream fileOut = new FileOutputStream(f);
            fileOut.write(inputStr.getBytes());
            fileOut.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
public static void main(String args[]) throws IOException {

    replaceSelected("Satti", "Hello");

}

}
