package com.jrtp2.main;

import com.jrtp2.model.Book;
import com.jrtp2.serviceimpl.BookServiceImpl;

public class BookServiceMainClass {

    public static void main(String args[]){

       BookServiceImpl bookServiceImpl =new BookServiceImpl();
       String str= bookServiceImpl.isBookAvailabe("104f");
       System.out.println(str);

       Book book =bookServiceImpl.printBookDetails("102f");
       if(book !=null) {
           System.out.println(book.bookId);
           System.out.println(book.bookName);
           System.out.println(book.bookPrice);
       } else{
           System.out.println("Book Details are Not Available");
       }

    }

}
