package com.jrtp2;

import java.util.*;

class Student {
    //implement this program
}

public class MapDemo {

    public static void main(String args[]){

        Student student =new Student();
          //  student =new Student("")


        Map<String,String> map= new HashMap<String, String>();

        map.put("101","Satti Babu" );
        map.put("102", "Harikha");
        map.put("103", "Shivesh");
        map.put("104", "Nikhila");

        Iterator<Map.Entry<String,String>> itr=map.entrySet().iterator();
        while(itr.hasNext()){
            Map.Entry<String, String> entryset=itr.next();
            //map.keySet();
            System.out.println(entryset.getKey());
            System.out.println(entryset.getValue());






        }




    }
}
