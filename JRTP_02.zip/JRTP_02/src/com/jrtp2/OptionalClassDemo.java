package com.jrtp2;

import java.util.Optional;

class OptionalDemo{

    public String getDefaultValue(){
        System.out.println("Default Value Method is Called");
        return "Raju";

    }

}



public class OptionalClassDemo {

public static void main(String args[]){
    String name="Satya";
    OptionalDemo optionalDemo=new OptionalDemo();
    //String str= Optional.ofNullable(name).orElse(optionalDemo.getDefaultValue());
 
    if(name ==null){
        throw new NullPointerException("Name is NUll");
    }

    String str= Optional.ofNullable(name).orElseGet(()-> optionalDemo.getDefaultValue());
    //String str=Optional.ofNullable(name)
    System.out.println(str);

}



}
