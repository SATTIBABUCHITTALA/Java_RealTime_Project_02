package com.jrtp2;

import java.util.concurrent.CompletableFuture;
import java.util.function.IntPredicate;
import java.util.stream.IntStream;

public class CompletableFeatureExample {

    public static Object object=new Object();

   private static IntPredicate evenPredicate=i->i%2==0;
   private static IntPredicate oddPredicate=i->i%2!=0;





        public static void printNumber(IntPredicate predicate){
            IntStream.rangeClosed(1,10).filter(predicate).forEach(CompletableFeatureExample::execute);
        }

    public static void execute(int no)
    {
        synchronized (object){

            try {
                System.out.println(Thread.currentThread().getName()+": " +no);

                object.notify();
                object.wait();

            } catch (InterruptedException e) {
                e.printStackTrace();
            }


        }



    }

    public static void main(String[] args) throws InterruptedException {
        CompletableFuture.runAsync(()->CompletableFeatureExample.printNumber(oddPredicate));
        CompletableFuture.runAsync(()->CompletableFeatureExample.printNumber(evenPredicate));
        Thread.sleep(1000);
    }
}
