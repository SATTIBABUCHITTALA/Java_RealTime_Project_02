
//Satti Babu



//Shivesh
public class PolymorphismDemo {
    public static void main(String args[]){

        Student student =new Student();
         student.getData(10);
///173637236373637


    }


}
