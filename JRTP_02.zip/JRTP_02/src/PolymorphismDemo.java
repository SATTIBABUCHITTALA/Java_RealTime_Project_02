
//Satti Babu


import java.util.function.BinaryOperator;

//Shivesh
public class PolymorphismDemo {
    public static void main(String args[]){

        Student student =new Student();
         student.getData(10);

         //list.stream().collect(Collectors.grouingBy(User::getDept(),Collectors.reducing(BinaryOperator.maxBy()))).
///173637236373637


    }


}
