public class ConditionalStatementDemo {

    public static void main(String args[]){

        int age= -5;
        String studentName="Vivek";

        if( age<17 && age>0 ){
            System.out.println("Teenager");
        }else if(age>17 && age<25){

            System.out.println("Youngster");
        }else if(age>30 && age<45){

            System.out.println("Middle Aged Person");
        }else if(age>=60){

            System.out.println("Eligible for Pension Scheme");
        }else {
            System.out.println("Invalid Entry");
        }

        int day=5;
        String dayofTheString = null;
        String dayString =null;
        //break and Continue ;

        switch(day) {


            case 1: dayofTheString ="Monday";

                    break;
            case 2: dayofTheString ="Tuesday";

                break;
            case 3: dayofTheString ="Wednesday";

                break;
            case 4: dayofTheString ="Thursday";

                break;
            case 5: dayofTheString ="Friday";

                break;
            case 6: dayofTheString ="Saturday";

                break;
            case 0 :dayofTheString ="Sunday";
                break;
            default : dayofTheString ="Invalid Entry for the Day";

        }
        //condition ? true : false;
        System.out.println(dayofTheString);
    }


}
