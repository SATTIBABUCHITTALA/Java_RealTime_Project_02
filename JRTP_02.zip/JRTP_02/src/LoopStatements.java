class Loop{

    void getValue(int i){
         i=30;

    }

}


public class LoopStatements {

    public static void main(String args[]){

        for(int i=0;i<10;i++) { //i=i+1;

            System.out.println(i);
        }
        //break Statement
        for(int i=0;i<10;i--){

            System.out.println(i);

            if(i==-10)
                break;
        }
        for(int i=0;i<10;i++){
            if(i==5)
                continue;
            else if(i==4){
                continue;
            }
            System.out.println(i);
            System.out.println("Hi");


        }

        int i=0;

        while(i<10){
            i++;
            System.out.println("I value"+ i);
        }
System.out.println("I "+i);
        do{

System.out.println("Do while Loop");
i++; // i=i+1;i=10+1; 11;
        }while(i<11);
//i =11;
        Loop loop =new Loop();
        loop.getValue(i);

        System.out.println("I Value now "+ i);
        for(i=0;i<10;i++){

            System.out.println(i);
        }
        double [] array={10,20,30,40,50}; //index will start from 0 to n-1 10 --0---9
        System.out.println("Normal For Loop");
        for(i=0;i<array.length;i++) //ctrl+shift+/ for multi commenting
                                      //
            System.out.print(array[i]+" ");
        System.out.println();
        System.out.println("Enhanced For Loop");
        for(double k:array){
            System.out.print(k +" ");
        }

    }

}

