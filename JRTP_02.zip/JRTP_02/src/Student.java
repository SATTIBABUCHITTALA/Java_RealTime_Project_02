

//Aug 2022 --- Feb 2023
public class Student {
    String studentName;

//method overlaoding
    void getData(int id){
        System.out.println("Student Details");
    }


    //Polymorphism
    void getData(int id,String name){

        System.out.println("Implementation has been changed");
    }


}