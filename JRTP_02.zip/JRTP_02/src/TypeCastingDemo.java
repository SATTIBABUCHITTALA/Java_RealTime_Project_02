public class TypeCastingDemo {

    public static void main(String args[]){

        System.out.println(args[1]);
        int salary=8000;

        double salaryDouble = salary;

        int sal= (int) salaryDouble;




    }

//syntax for forloop
}
